HOW TO INSTALL ADDONS

Create a C:\KMOD folder

Create a C:\KMOD\Player folder

Put both folders in this extract into the "Player" directory.

Load the game and you'll have the mods!

RealismMovement: Changes the movement speed

GunNoises: Realism