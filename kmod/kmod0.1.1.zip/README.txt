KMOD Itch.io 0.1.0

Contains:
- KMOD Binary
- KMOD SDK
- KMOD game
- Discord DLLs
- Tree Generator DLLs
- Map DLCs

HOW TO INSTALL DLCS: 

create a C:\KMOD directory if it doesn't exist.

Copy all the contents of "DLC/" to "C:\KMOD\Maps (create it if it doesn't exist)

Note: Documentation is now hosted @ https://thekaigonzalez.github.io/kmoddevs