ChangeLog:

Fixes issues with non-high-end mid-range hardware (Real-time soft shadows)
Adds many new features
Remove MODS from the archive, look at the Repository.

Welcome to KMOD! the most free sandbox in-dev game ever,
download patches, read dev docs, and much more!

CONTROLS:

W-A-S-D: Movement

Space: Jumping

1: Hands

2: Block gun (50 dph)

Scroll wheel (Soon): Cycle through modified guns

CTRL: Sliding speed-based movement

A and D: Tilt (Comes with movement)

KMOD Comes with discord integration!

If you want to support, report bugs, or get new feature announcements, please check out https://discord.gg/hUyyrvmZcc (our server!)